package com.example.verificationcode;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(name = "helloServlet", urlPatterns = {"/login.do"})
public class HelloServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String userCaptcha = request.getParameter("verification");
        String captcha = request.getParameter("generatedCaptcha");
        response.setContentType("text/html;charset=UTF-8");
        OutputStream outputStream = response.getOutputStream();
        // 验证验证码是否正确
        String responseMessage;
        if (userCaptcha != null && userCaptcha.equals(captcha)) {
            responseMessage = "验证码正确，登录成功！";
        } else {
            responseMessage = "验证码错误，请重试！";
        }
        // 使用输出流写出响应信息
        outputStream.write(responseMessage.getBytes(StandardCharsets.UTF_8));
        outputStream.flush();
        outputStream.close();
    }
}